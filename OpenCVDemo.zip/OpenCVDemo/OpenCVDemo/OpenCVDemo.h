
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <cv.h>
#include <highgui.h>
#include <cvaux.h>

void CannyDemo(void);
void DisplayImageDemo(void);
void DisplayVideoDemo(void);
void CaptureVideoDemo(void);
void Drawing0Demo(void);
void AlphaBlendDemo(void);
void GaussianBlurDemo(void);
void MouseEventDemo(void);
void FiltersDemo(void);
//void ThresholdDemo(void);
void FaceDetection2Demo(void);
void FaceDetectionVideoDemo(void);
void Blobs0Demo(void);
void Blobs1Demo(void);
void RecordVideoDemo(void);