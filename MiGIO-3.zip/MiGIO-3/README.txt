MiGIO (IRP 2010)
-----------------------

Release Version 1.0b
Interface code to Rovio and Pleo 

Pleo
------
Requires migio1.0b firmware
COM Port set between COM4 and COM9

